export function getuser() {
	return {
		name: 'hi',
	}
}
