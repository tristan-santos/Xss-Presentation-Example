// import { initializeApp } from 'https://www.gstatic.com/firebasejs/9.13.0/firebase-app.js'
// import { getAnalytics } from 'https://www.gstatic.com/firebasejs/9.13.0/firebase-analytics.js'
// const firebaseConfig = {
// 	apiKey: 'AIzaSyDF9AeGoi06xB2-sMH9Qjn2l9YqR1cgS_w',
// 	authDomain: 'tristan-victor-presentation.firebaseapp.com',
// 	projectId: 'tristan-victor-presentation',
// 	storageBucket: 'tristan-victor-presentation.appspot.com',
// 	messagingSenderId: '777873716301',
// 	appId: '1:777873716301:web:e8aa847cbacecbad1d5804',
// 	measurementId: 'G-K0KB71KEZE',
// }

// const app = initializeApp(firebaseConfig)
// const analytics = getAnalytics(app)

import { parser } from './parser.js'
import { getuser } from './getuser.js'
import { googleLogin } from './googleauth.js'
import { TitleAnimation } from './titleAnimation.js'
import { createUserInput, db, App } from './input.js'

// TitleAnimation()
createUserInput()
const googlebtn = document.querySelector('.user-auth')
const userInput = document.querySelector('.user-get')
googlebtn.addEventListener('click', () => {
	googleLogin(userInput.value)
})
// parser('Tristan Joseph', '104737100252', 'Santos')
console.log(db, App)
