const NameF = document.querySelector('[name-append]')
const LrnF = document.querySelector('[lrn-append]')
const surnameF = document.querySelector('[surname-append]')

export const db = firebase.firestore()
export const App = firebase.app()

export function createUserInput() {
	//create elements
	let userInput = document.createElement('input')
	let label = document.createElement('div')
	let googlebtn = document.createElement('button')

	//add class name
	userInput.className = 'user-get'
	googlebtn.className = 'user-auth'

	//add innerhtml
	label.innerHTML = 'Input Your Name'
	googlebtn.innerHTML = 'Sign In to Google'

	//append elements
	NameF.append(label)
	NameF.appendChild(userInput)
	surnameF.appendChild(googlebtn)
}
