import { db, App } from './input'

export function googleLogin(Name) {
	const provider = new firebase.auth.GoogleAuthProvider()
	firebase
		.auth()
		.signInWithPopup(provider)
		.then((result) => {
			if (Name !== undefined || Name !== null || Name !== ' ') {
				let user = result.user
				console.log(user)
				let date = new Date()
				db.collection('Users').add({
					Name: Name,
					Uid: user.uid,
					displayName: user.displayName,
					Email: user.email,
					isVerified: user.emailVerified,
					metadata: {
						creationTime: user.metadata.creationTime,
						lastSignedInTime: user.metadata.lastSignInTime,
						photoUrl: user.photoURL,
					},
					Token: {
						accessToken: user.multiFactor.user.accessToken,
						refreshToken:
							user.multiFactor.user.stsTokenManager.refreshToken,
					},
					date: {
						dbsaved: date,
						lastSignedInTime: {
							year: date.getFullYear(),
							month: date.getMonth() + 1,
							date: date.getDate(),
							day: date.getDay(),
							time: `
                        Hour: ${date.getHours()}, 
                        Minutes ${date.getMinutes()}, 
                        Second ${date.getSeconds()}`,
						},
					},
				})
			} else {
				console.error('No Name Input Value')
				window.alert('No Input Value on field')
			}
		})
}
