export function TitleAnimation() {
	let t = document.querySelector('title')
	setInterval(() => {
		setTimeout(() => {
			t.innerHTML = 'Welcome'
		}, 100)
		setTimeout(() => {
			t.innerHTML = 'Welcome to'
		}, 500)
		setTimeout(() => {
			t.innerHTML = "Welcome to Tristan's"
		}, 1000)
		setTimeout(() => {
			t.innerHTML = "Welcome to Tristan's Website"
		}, 2000)
		console.clear()
	}, 3000)
}
