const path = require('path')

module.exports = {
	mode: 'production',
	entry: './public/typescript/module.js',
	output: {
		path: path.resolve(__dirname, 'public'),
		filename: 'Tristan.js',
	},
	watch: true,
}
